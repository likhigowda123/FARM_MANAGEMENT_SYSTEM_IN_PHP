<div class="container-fluid animatedParent" style="background:#F8F9FA; padding:40px;"> 
		    <div class="container">
		      
			      <div class="row animated fadeIn">
				      
					  
					  <div class="col-sm-6" style=" border-right:1px solid black;">
					    <ul>
                          <li><h5>ADMIN SECTION</h5></li>
						  <li><a href="../admin.php">Admin Login</a></li>
						  
						</ul>
					  </div>
					  
					  <div class="col-sm-6" style=" border-right:1px solid black;">
					     <ul>
						  <li><h5>HOTEL LINKS</h5></li>
						  <li><a href="../vendor-new.php">Register On Food Hunt</a></li>
						  <li><a href="../vendor_login.php">Hotel Account Login</a></li>
						  <li><a href="../food.php">Add Foods</a></li>
						  
						</ul>
					  </div>
				  </div>
			 </div>
			 			 
		  </div>